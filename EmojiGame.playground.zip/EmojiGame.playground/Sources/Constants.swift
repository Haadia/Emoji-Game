import Foundation


public var emojiCount = 0
public var count = 0
public var trainingSamplePerLabel = 3
public var flag = false
public var compiledURL: URL?
public var initialFlag = flag

public var emojisArray = ["🙂","😛", "😊", "☹️"]

//public var emojisArray = ["🙂", "😍", "😛", "😊", "☹️", "😯", "😠"]
